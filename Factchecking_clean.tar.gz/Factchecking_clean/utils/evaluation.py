import csv
import datetime


def evaluate_run_save_to_file(y_test, predicted, run_name, notes):
    true_positive = 0
    false_negative = 0
    true_negative = 0
    false_positive = 0
    for p, actual in zip(predicted, y_test):
        if actual == 1:
            if actual == p:
                true_positive += 1
            else:
                false_negative += 1
        else:
            if actual == p:
                true_negative += 1
            else:
                false_positive += 1

    accuracy = (true_positive + true_negative) / (false_negative + true_positive + false_positive + true_negative)
    precision = true_positive / (true_positive + false_positive)
    recall = true_positive / (true_positive + false_negative)
    fScore = 2 * (precision * recall) / (precision + recall)
    with open('run-results_new.tsv', 'a+', newline='') as csvFile:
        writer = csv.writer(csvFile, delimiter='\t')
        result = [run_name, str(datetime.datetime.now()), true_positive, true_negative, false_positive,
                  false_negative, accuracy, precision, recall, fScore, notes]
        print(result)
        writer.writerow(result)
