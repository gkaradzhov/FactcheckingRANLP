import numpy as np


def get_embeddings():
    embeddings_index = {}
    f = open('/dev/shm/glove.6B.300d.txt')  # path to embeddigns
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = coefs
    f.close()

    return embeddings_index
