from keras import optimizers
from keras.layers import Merge
from keras.models import Model

from classification.lstm_utils import *
from utils.data_splits import *
from utils.load_data import *
from utils.resources import get_embeddings


def save_intermediate(model, layer_name, output_name, ids, test_data):
    intermediate_layer_model = Model(inputs=model.input,
                                     outputs=model.get_layer(layer_name).output)

    intermediate_output = intermediate_layer_model.predict(test_data)

    with open('../data/feature_sets/' + output_name, 'w', encoding='utf8') as w:
        for o, claim in zip(intermediate_output, ids):
            resStr = [str(item) for item in o]
            resStr = '\t'.join(resStr)
            w.write(claim + '\t' + resStr + '\n')


embedding_index = get_embeddings()

claims = load_claims()

claim_texts = [qa[2] for qa in claims]

claim_ids = [qa[0] for qa in claims]
y = [1 if 'true' in qa[1] else 0 for qa in claims]

web_data = load_snippets()
web = [w[1] for w in web_data]

similarities = load_similarities()
sims = [sim[1:] for sim in similarities]
wvec = load_avg_vectors()
avg_vec = [avg[1:] for avg in wvec]

x_repres_claim_vectors = text_to_embeddings(claim_texts, embedding_index)

x_repres_sim = np.asarray(sims)
x_repres_avg = np.asarray(avg_vec)
x_repres_web_vectors = text_to_embeddings(web, embedding_index)

input_data = [x_repres_claim_vectors, x_repres_sim, x_repres_avg, x_repres_web_vectors]

model = Sequential()
model_claims = GenerateLstm('claim_emb')
model_sim = GeneratePerceptron(x_repres_sim, 30)
model_avg = GeneratePerceptron(x_repres_avg, 40)
model_web = GenerateLstm('web_emb')
multiply_merge = Merge([model_claims, model_web], mode='mul')
substract_merge = Merge([model_claims, model_web], mode='sum')
model.add(Merge([model_claims, model_sim, model_avg, model_web, multiply_merge, substract_merge], mode='concat',
                name='combined_representation1'))

model.add(Dense(100, name='hidden', init='normal', activation='softmax'))
model.add(Dense(100, name='combined_representation2', init='normal', activation='tanh'))
model.add(Dense(1, init='normal', activation='relu'))

sgd = optimizers.Nadam()
model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['acc'])

model.load_weights('../data/saved_models/lstm_substract_multiply')
save_intermediate(model, 'claim_emb', 'claim_embedding', claim_ids, input_data)
save_intermediate(model, 'web_emb', 'web_embedding', claim_ids, input_data)
save_intermediate(model, 'combined_representation1', 'combined_representation', claim_ids, input_data)
save_intermediate(model, 'combined_representation2', 'combined_representation2', claim_ids, input_data)
