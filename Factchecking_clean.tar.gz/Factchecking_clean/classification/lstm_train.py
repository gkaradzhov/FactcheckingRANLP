from __future__ import print_function

from keras import optimizers
from keras.callbacks import ModelCheckpoint
from keras.layers import Merge, Lambda

from classification.lstm_utils import *
from utils.data_splits import get_train, get_val
from utils.load_data import load_claims, load_snippets, load_avg_vectors, load_similarities
from utils.resources import get_embeddings

batch_size = 32
embedding_index = get_embeddings()

claims = load_claims()

claim_text = [c[2] for c in claims]
claim_ids = [qa[0] for qa in claims]
y = [1 if 'true' in qa[1] else 0 for qa in claims]

web_data = load_snippets()
web = [w[1] for w in web_data]

similarities = load_similarities()
sims = [sim[1:] for sim in similarities]
wvec = load_avg_vectors()
avg_vec = [avg[1:] for avg in wvec]

x_train_claim, y_train_claim = get_train(claim_ids, claim_text, y)
print(x_train_claim[0])
print(y_train_claim[0])
x_val_claim, y_val_claim = get_val(claim_ids, claim_text, y)
print(x_val_claim[0])
print(y_val_claim[0])
x_train_claim_vectors = text_to_embeddings(x_train_claim, embedding_index)
print(x_train_claim_vectors[0])
x_val_claim_vectors = text_to_embeddings(x_val_claim, embedding_index)

x_train_sim, y_train_sim = get_train(claim_ids, sims, y)
x_train_sim = np.asarray(x_train_sim)
x_val_sim, y_val_sim = get_val(claim_ids, sims, y)
x_val_sim = np.asarray(x_val_sim)

x_train_avg, y_train_avg = get_train(claim_ids, avg_vec, y)
x_train_avg = np.asarray(x_train_avg)
x_val_avg, y_val_avg = get_val(claim_ids, avg_vec, y)
x_val_avg = np.asarray(x_val_avg)

x_train_web, y_train_web = get_train(claim_ids, web, y)
print(x_train_web[0])
print(y_train_web[0])
x_val_web, y_val_web = get_val(claim_ids, web, y)
x_train_web_vectors = text_to_embeddings(x_train_web, embedding_index)
print(x_train_web_vectors[0])
x_val_web_vectors = text_to_embeddings(x_val_web, embedding_index)

model = Sequential()
model_claims = GenerateLstm('claim_emb')
model_sim = GeneratePerceptron(x_train_sim, 30)
model_avg = GeneratePerceptron(x_train_avg, 40)
model_web = GenerateLstm('web_emb')
model_web_2 = GenerateLstm('web_emb_2')
multiply_merge = Merge([model_claims, model_web], mode='mul')

# To apply substract operation we first multiply one of the sources by -1, sum it, with the other source and calculate absolute values
model_copy = Sequential()
model_copy.add(model_web)
model_copy.add(Lambda(reverse))
merge = Merge([model_claims, model_copy], mode='sum')
model_copy.add(Lambda(absolute))

model.add(Merge([model_claims, model_sim, model_avg, model_web, multiply_merge, model_copy], mode='concat',
                name='combined_representation1'))

model.add(Dense(80, name='hidden', init='normal', activation='tanh'))
model.add(Dense(25, name='combined_representation2', init='normal', activation='tanh'))
model.add(Dense(1, init='normal', activation='tanh'))

sgd = optimizers.Adam()
model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['acc'])

model_name = "lstm_substract_multiply_propper"
print(model_name)

cb = ModelCheckpoint('../data/saved_models/' + model_name, monitor='val_acc', verbose=1,
                     save_best_only=True, save_weights_only=False,
                     mode='auto', period=1)

model.fit(
    [x_train_claim_vectors, x_train_sim, x_train_avg, x_train_web_vectors],
    y_train_claim,
    batch_size=batch_size,
    epochs=50,
    callbacks=[cb],
    validation_data=[[x_val_claim_vectors, x_val_sim, x_val_avg, x_val_web_vectors], y_val_claim])
