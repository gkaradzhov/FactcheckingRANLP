import numpy as np
from keras import regularizers
from keras.layers import Dense, Dropout, LSTM, Bidirectional
from keras.models import Sequential


def GeneratePerceptron(X, hidden_size):
    model_perceptron = Sequential()
    # model_perceptron.add(Dense(hidden_size, activation='linear',init='normal', input_shape=(X.shape[1],)))
    # model_perceptron.add(Dropout(0.3))
    model_perceptron.add(Dense(hidden_size, activation='tanh', init='normal', input_shape=(X.shape[1],),
                               activity_regularizer=regularizers.l2(0.1)))
    return model_perceptron


def GenerateLstm(embedding_name):
    model = Sequential()

    bi_layer = Bidirectional(LSTM(25, activity_regularizer=regularizers.l2(0.1)), input_shape=(25, 300),
                             name=embedding_name)
    model.add(bi_layer)
    dropout = Dropout(0.5)
    model.add(dropout)
    # model.add(Bidirectional(LSTM(50, activity_regularizer=regularizers.l2(0.01)), name=embedding_name))
    # model.add(Dropout(0.5))

    return model


from utils.NLTKPreprocessor import NLTKPreprocessor

prerpocessorNLTK = NLTKPreprocessor('regular').preprocessString
tokenizerRaw = NLTKPreprocessor('regular').tokenizeDocumentRaw


def text_to_embeddings(X, embeddings_index):
    x_train_np = np.full((len(X), 25, 300), 0.0, dtype='object')
    for i, x in enumerate(X):
        split = tokenizerRaw(x.lower())
        count = 0
        res = np.full((25, 300), 0, dtype='object')
        for w in split:
            if count == 25:
                break
            else:
                if w in embeddings_index:
                    res[count] = np.array(embeddings_index[w], dtype='float')
                    count += 1
        x_train_np[i] = res
    return x_train_np


def reverse(X):
    reversed = X * -1  # get last element from time dim
    return reversed


def absolute(X):
    abs = np.absolute(X)
    return abs
