from keras import optimizers
from keras.layers import Merge

from classification.lstm_utils import *
from utils.data_splits import *
from utils.evaluation import evaluate_run_save_to_file
from utils.load_data import *
from utils.resources import get_embeddings

# TODO: Georgi: I didn't manage to make loading model work without compiling the architecture first
# TODO:         It should be possible to load model weights+architecture only from file.

embedding_index = get_embeddings()

claims = load_claims()

claims_text = [qa[2] for qa in claims]

claims_ids = [qa[0] for qa in claims]
y = [1 if 'true' in qa[1] else 0 for qa in claims]

web_data = load_snippets()
web = [w[1] for w in web_data]

similarities = load_similarities()
sims = [sim[1:] for sim in similarities]
wvec = load_avg_vectors()
avg_vec = [avg[1:] for avg in wvec]

x_test_claims, y_test_claims = get_test(claims_ids, claims_text, y)
x_test_claim_vectors = text_to_embeddings(x_test_claims, embedding_index)

x_test_sim, y_test_sim = get_test(claims_ids, sims, y)
x_test_sim = np.asarray(x_test_sim)

x_test_avg, y_test_avg = get_test(claims_ids, avg_vec, y)
x_test_avg = np.asarray(x_test_avg)

x_test_web, y_test_web = get_test(claims_ids, web, y)
x_test_web_vectors = text_to_embeddings(x_test_web, embedding_index)

model = Sequential()
model_claims = GenerateLstm('claim_emb')
model_sim = GeneratePerceptron(x_test_sim, 30)
model_avg = GeneratePerceptron(x_test_avg, 80)
model_web = GenerateLstm('web_emb')
multiply_merge = Merge([model_claims, model_web], mode='mul')
substract_merge = Merge([model_claims, model_web], mode='sum')
model.add(Merge([model_claims, model_sim, model_avg, model_web, multiply_merge, substract_merge], mode='concat',
                name='combined_representation1'))

model.add(Dense(100, name='hidden', init='normal', activation='softmax'))
model.add(Dense(100, name='combined_representation2', init='normal', activation='tanh'))
model.add(Dense(1, init='normal', activation='relu'))

sgd = optimizers.Nadam()
model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['acc'])
model.load_weights('../data/saved_models/lstm_substract_multiply')

predicted = model.predict([x_test_claim_vectors, x_test_sim, x_test_avg, x_test_web_vectors])

print(predicted)
p_classes = []
for p in predicted:
    if p > 0.5:
        p_classes.append(1)
    else:
        p_classes.append(0)

evaluate_run_save_to_file(y_test_claims, p_classes, 'lstm_substract_multiply')
