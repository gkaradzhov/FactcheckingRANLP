from collections import defaultdict

from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import KFold
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVC

from utils.data_splits import *
from utils.evaluation import evaluate_run_save_to_file
from utils.load_data import *


def addFeatureFile(currentFeatures, newFilePath):
    with open(newFilePath, 'r+') as readFile:
        reader = csv.reader(readFile, delimiter='\t', lineterminator='\n')
        count = 0
        for record in reader:
            if len(record) != 0:
                key = record[0]
                if key in currentFeatures:
                    currentFeatures[key].extend(record[1:])
                else:
                    currentFeatures[key] = record[1:]
            else:
                print(count)
            count += 1


def run(runName, featureFiles):
    import datetime
    print(str(datetime.datetime.now()) + " ] starting run:" + runName)

    features = defaultdict(dict)
    pathToFeatureFiles = '../data/feature_sets/'

    for f in featureFiles:
        newFilePath = pathToFeatureFiles + str(f)
        addFeatureFile(features, newFilePath)

    data = load_claims()
    claim_ids = [qa[0] for qa in data]
    X = []
    Y = [1 if 'true' in qa[1] else 0 for qa in data]

    for id in claim_ids:
        X += [features[id]]

    min_max_scaler = MinMaxScaler()
    X = min_max_scaler.fit_transform(X)

    param_grid = [
        {'C': [1, 8, 32, 128, 512], 'gamma': [3, 1, 0.1, 0.001], 'kernel': ['rbf', 'linear']},
    ]

    kFold = KFold(n_splits=5, shuffle=True, random_state=1)
    print("Gridsearch start")
    clf = GridSearchCV(SVC(C=1), param_grid, cv=kFold,
                       scoring='accuracy', n_jobs=6)
    # clf = SVC(C=3, gamma=0.001, kernel='rbf')

    Xtrain, Ytrain = get_train(claim_ids, X, Y)
    Xtest, Ytest = get_test(claim_ids, X, Y)
    clf.fit(Xtrain, Ytrain)
    # print(clfTunned.best_score_)
    print(clf.best_params_)
    #
    clf = clf.best_estimator_

    clf = clf.fit(Xtrain, Ytrain)
    predicted = clf.predict(Xtest)

    evaluate_run_save_to_file(Ytest, predicted, runName)


if __name__ == '__main__':
    from multiprocessing import freeze_support

    freeze_support()
    # run('features_without_lstm_embeddings',
    #    ['similarities',
    #     'avg_vector'])
    run('all_features_with_lstm', ['similarities',
                                   'avg_vector', 'claim_embedding', 'web_embedding', 'combined_representation',
                                   'combined_representation2'])

    run('only_lstm_embeddings',
        ['claim_embedding', 'web_embedding', 'combined_representation', 'combined_representation2'])
