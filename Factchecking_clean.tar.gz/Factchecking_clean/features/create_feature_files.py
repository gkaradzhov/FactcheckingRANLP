import csv
import json

from utils.NLTKPreprocessor import NLTKPreprocessor
from utils.load_data import load_claims
from utils.resources import get_embeddings
from utils.vector_utils import get_max, get_mean, get_min, get_text_vector

prerpocessorNLTK = NLTKPreprocessor('regular').preprocessString
tokenizerRaw = NLTKPreprocessor('regular').tokenizeDocumentRaw


def aggregate_sims_for_array(simms_array):
    if len(simms_array) == 0:
        return [0, 0, 0, 0, 0, 0]
    else:
        return [simms_array[0],
                get_max(simms_array[:3]),
                get_mean(simms_array[:3]),
                get_max(simms_array),
                get_mean(simms_array),
                get_min(simms_array)]


def generate_similarities_feature_file():
    data = load_claims()
    result = []
    for d in data:
        claim_stats = []
        with open('../data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)
        claim_stats.append(claim_object['id'])
        claim_stats.extend(aggregate_sims_for_array(claim_object['snippetToClaimTfIdf']))
        claim_stats.extend(aggregate_sims_for_array(claim_object['snippetToClaimContainment']))
        claim_stats.extend(aggregate_sims_for_array(claim_object['snippetToClaimVector']))
        result.append(claim_stats)
    with open('../data/feature_sets/similarities', 'w+') as write:
        csv_writer = csv.writer(write, delimiter='\t')
        for line in result:
            csv_writer.writerow(line)


def generate_avg_vector():
    data = load_claims()
    embeddings = get_embeddings()
    result = []
    for d in data:
        claim_stats = []
        with open('../data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)
        claim_stats.append(claim_object['id'])
        best_snippet = get_best_snippet(claim_object)
        claim_stats.extend(get_text_vector(best_snippet, embeddings, tokenizerRaw))

        claim = d[2]
        claim_stats.extend(get_text_vector(claim, embeddings, tokenizerRaw))

        result.append(claim_stats)
    with open('../data/feature_sets/avg_vector', 'w+') as write:
        csv_writer = csv.writer(write, delimiter='\t')
        for line in result:
            csv_writer.writerow(line)


def generate_best_snippet():
    data = load_claims()
    result = []
    for d in data:
        claim_stats = []
        with open('../data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)
        claim_stats.append(claim_object['id'])
        best_snippet = get_best_snippet(claim_object)
        claim_stats.append(best_snippet)
        result.append(claim_stats)
    with open('../data/feature_sets/best_snippets', 'w+') as write:
        csv_writer = csv.writer(write, delimiter='\t')
        for line in result:
            csv_writer.writerow(line)


def get_best_snippet(claim_object):
    if len(claim_object['snippetToClaimVector']) == 0:
        return ' '
    else:
        index = claim_object['snippetToClaimVector'].index(max(claim_object['snippetToClaimVector']))
        return claim_object['sinppets_clean'][index]


# generate_similarities_feature_file()
generate_avg_vector()
generate_best_snippet()
