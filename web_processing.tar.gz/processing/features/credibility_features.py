from utils.resources import get_website_credibility
import json
from utils.load_data import load_claims

def calculate_features():
    data = load_claims()
    credibility_list = get_website_credibility()
    for d in data:
        print(d[0])
        with open('../data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)
        claim_object['site_cred'] = []
        claim_object['sim_cred'] = []
        claim_object['pos_count'] = []
        claim_object['neg_count'] = []
        claim_object['neu_count'] = []
        for index, item in enumerate(claim_object['displayUrl']):
            claim_object['site_cred'].append(credibility_list[item]['credibility'])
            claim_object['pos_count'].append(credibility_list[item]['pos_count'])
            claim_object['neg_count'].append(credibility_list[item]['neg_count'])
            claim_object['neu_count'].append(credibility_list[item]['neu_count'])
            claim_object['sim_cred'].append(credibility_list[item]['credibility'] * claim_object['websiteToClaimVectorAvg'][index])

        with open('../data/web_augmentation/external/' + d[0] + '.json', 'w') as outfile:
            json.dump(claim_object, outfile, indent=2)

calculate_features()