import numpy as np
from nltk.util import ngrams
from sklearn.feature_extraction.text import TfidfVectorizer
from utils.NLTKPreprocessor import NLTKPreprocessor
from utils.load_data import load_claims
import json
from utils.resources import get_embeddings
from utils.vector_utils import *
from sklearn.metrics.pairwise import cosine_similarity

prerpocessorNLTK = NLTKPreprocessor('regular').preprocessString
tokenizerRaw = NLTKPreprocessor('regular').tokenizeDocumentRaw
tokenizerLemma = NLTKPreprocessor('regular').tokenizeDocument
vectorizer = TfidfVectorizer(preprocessor=prerpocessorNLTK)


def calculate_tfidf_sim(text1, text2):
    tfidf = vectorizer.fit_transform([text1, text2])
    return (tfidf * tfidf.T).A[0, 1].tolist()


def calculate_embedding_similarity(text1, text2, embeddings):
    text1_vector = get_text_vector(text1, embeddings, tokenizerRaw).reshape(1, -1)
    text2_vector = get_text_vector(text2, embeddings, tokenizerRaw).reshape(1, -1)

    if type(text1_vector) is not np.ndarray or type(text2_vector) is not np.ndarray:
        return 0

    result = cosine_similarity(text1_vector, text2_vector).tolist()[0][0]
    return result


def calculate_containment_metric(text1, text2):
    if len(text1) > 5000:
        text1 = text1[:5000]
    tokens1 = tokenizerLemma(text1)
    tokens2 = tokenizerLemma(text2)
    text1_trigrams = set(ngrams(tokens1, 3))
    text2_trigrams = set(ngrams(tokens2, 3))

    coloca = len([x for x in text1_trigrams if x in text2_trigrams])

    if len(text2_trigrams) == 0:
        return 0

    similarity = coloca / len(text2_trigrams)

    return similarity


def clean_text(text):
    import re
    content = re.sub(r'[^\x00-\x7F]+', ' ', text)
    content = re.sub('\s+', ' ', content)
    content = content.encode('ascii', errors='ignore').decode("ascii")
    return content


def process_websites(object, embeddings):
    from nltk import sent_tokenize
    for text in object['html']:
        print("calculate containment metric")
        # for containment metric we can take the whole page
        object['websiteToClaimContainment'].append(
            calculate_containment_metric(object['claim'], text))
#
        text = text[:15000]
        sentences = sent_tokenize(text, language='english')
        grams = [sentences[i:i + 3] for i in range(len(sentences) - 3 + 1)]
        print("grams getted")

        tfidf = []
        word_vectors = []
        best_sentence = ''
        best_vector_sim = 0
        for gram in grams:
            gram_text = '. '.join(gram)
            tfidf.append(
                calculate_tfidf_sim(object['claim'], gram_text))

            vector_sim = calculate_embedding_similarity(object['claim'], gram_text, embeddings)
            if vector_sim > best_vector_sim:
                best_vector_sim = vector_sim
                best_sentence = gram_text
            word_vectors.append(vector_sim)

        object['websiteBestTriplet'].append(best_sentence)
        object['websiteToClaimTfIdfAvg'].append(get_mean(tfidf))
        object['websiteToClaimTfIdfMax'].append(get_max(tfidf))
        object['websiteToClaimVectorAvg'].append(get_mean(word_vectors))
        object['websiteToClaimVectorMax'].append(get_max(word_vectors))


def disregard_source(link):
    bad_sources = ['snopes.com', 'youtube.com', 'factcheck.org', 'politifact.com', 'truthorfiction.com', 'hoax-slayer.com']
    for source in bad_sources:
        if source in link:
            return True
    return False


def process():
    data = load_claims()
    embeddings = get_embeddings()
    for d in data:
        print(d[1])
        with open('data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)

        claim_text = d[2]
        claim_object['claim'] = claim_text
        claim_object['snippetToClaimTfIdf'] = []
        claim_object['snippetToClaimContainment'] = []
        claim_object['snippetToClaimVector'] = []

        claim_object['websiteToClaimContainment'] = []
        claim_object['websiteToClaimTfIdfAvg'] = []
        claim_object['websiteToClaimTfIdfMax'] = []
        claim_object['websiteToClaimVectorAvg'] = []
        claim_object['websiteToClaimVectorMax'] = []
        claim_object['websiteBestTriplet'] = []
        claim_object['sinppets_clean'] = []
        for link, snippet in zip(claim_object['links'], claim_object['snippets']):
            if disregard_source(link):
                print('Disregarding', link)
                continue

            #process snippet
            clean_snippet = clean_text(snippet)
            claim_object['sinppets_clean'].append(clean_snippet)
            claim_object['snippetToClaimTfIdf'].append(calculate_tfidf_sim(claim_text, clean_snippet))
            claim_object['snippetToClaimContainment'].append(calculate_containment_metric(claim_text, clean_snippet))
            print(claim_text)
            print(clean_snippet)

            claim_object['snippetToClaimVector'].append(calculate_embedding_similarity(claim_text, clean_snippet, embeddings))


            #process website
        process_websites(claim_object, embeddings)

        with open('data/web_augmentation/external/' + d[0] + '.json', 'w') as outfile:
            json.dump(claim_object, outfile, indent=2)


if __name__ == '__main__':
    process()
