from nltk import ne_chunk, pos_tag, word_tokenize
from nltk.tree import Tree
import utils.TfIdf as tf
import nltk
from utils.load_data import load_claims
import csv, os
csv.field_size_limit(3000000)


def get_named_entities(text):
        chunked = ne_chunk(pos_tag(word_tokenize(text)))
        continuous_chunk = []
        current_chunk = []
        for i in chunked:
            if type(i) == Tree:
                current_chunk.append(" ".join([token for token, pos in i.leaves()]))
            elif current_chunk:
                named_entity = " ".join(current_chunk)
                if named_entity not in continuous_chunk:
                    continuous_chunk.append(named_entity)
                    current_chunk = []
            else:
                continue
        return continuous_chunk

def getKeyPhrases(text, tfidf):
    verb = []
    noun = []
    adj = []
    ranked_words = tfidf.get_doc_keywords(text)
    ranked_words = dict(ranked_words)
    wordsWithPos = nltk.pos_tag(nltk.word_tokenize(text))
    named_entities = get_named_entities(text)

    res_obj = []

    for word in wordsWithPos:
        w = word[0]
        pos_tag = word[1][0]
        if str.lower(w) in ranked_words:
            score = ranked_words[str.lower(w)]
        else:
            score = 0
        res_obj.append([w, pos_tag, score])

    named_entities_str = [str.format("'{}'", n) for n in named_entities]
    res_obj.sort(key=lambda x: x[2], reverse=True)
    for word in res_obj:
        wLower = word[0].lower()
        wordExists = False
        for ne in named_entities:

            neLower = ne.lower()
            if wLower in neLower:
                wordExists = True
                break

        if wordExists:
            continue
        if word[1] == 'V' and wLower not in verb:
            verb.append(wLower)
        if word[1] == 'N' and wLower not in noun:
            noun.append(wLower)
        if word[1] == 'J' and wLower not in adj:
            adj.append(wLower)

    named_entities_str = named_entities_str[:3]
    noun = noun[:4]
    verb = verb[:3]

    if len(named_entities_str[:3]) + len(noun[:3]) + len(verb[:3]) <= 6:
        adj = adj[:3]
    else:
        adj = adj[:1]

    return named_entities_str, noun, verb, adj

def extract_queries():
    tfidf = tf.TfIdf("data/QLIDF.txt")
    qas = load_claims()
    resulted_queries = []

    compr = [[qa[0], qa[2]] for qa in qas]

    for item in compr:
        qa_id, qa_concat = item[0], item[1]
        named_entities_str, noun, verb, adj = getKeyPhrases(qa_concat, tfidf)
        obj = {'id': qa_id,
               'nes': named_entities_str,
               'nouns': noun,
               'verbs': verb,
               'adj': adj}
        resulted_queries.append(obj)

    import json
    with open('data/claims_queries', 'w+') as w:
        for item in resulted_queries:
            w.write(json.dumps(item) + '\n')



if __name__ == '__main__':
    extract_queries()