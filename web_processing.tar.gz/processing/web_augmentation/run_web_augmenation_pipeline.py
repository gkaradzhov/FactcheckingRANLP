from features.create_feature_files import generate_similarities_feature_file, generate_avg_vector, \
    generate_best_snippet, generate_best_webpage_triplet
from web_augmentation.process_search_engines_crawl import process_google
from web_augmentation.extract_query_parts import extract_queries
from features.similarities import process as calculate_similarities

if __name__ == '__main__':
    print("-------Start processing-------")

    print("-------Started extracting query parts-------")
    extract_queries()
    print("-------Finished extracting query parts-------")

    print("-------Started querying web and crawling websites-------")
    process_google()
    print("-------Finished querying web and crawling websites-------")

    print("-------Started calculating similarities-------")
    calculate_similarities()
    print("-------Finished calculating similarities-------")

    print("-------Started creating final feature files-------")
    generate_similarities_feature_file()
    generate_avg_vector()
    generate_best_snippet()
    generate_best_webpage_triplet()
    print("-------Finished creating final feature files-------")

    print("-------Finished processing-------")