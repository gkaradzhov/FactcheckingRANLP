from urllib.request import Request

from web_augmentation.google_search import GoogleSearch
from web_augmentation.bing_search import *
import copy
import operator
from bs4 import BeautifulSoup
import re
import json
from time import sleep
from utils import load_data
from web_augmentation.extract_query_parts import extract_queries


def generate_search_query(nes, nouns, verbs, adjs, reduce_factor=0):
    named_entities = nes
    nouns = nouns
    verbs = verbs
    adjectives = adjs
    item_dicts = {'adj': adjectives,
                       'nouns': nouns,
                       'named_entities': named_entities,
                       'verbs': verbs}
    while reduce_factor > 0:
        length_list = {'adj': len(item_dicts['adj']),
                       'nouns': len(item_dicts['nouns']),
                       'named_entities': len(item_dicts['named_entities']),
                       'verbs': len(item_dicts['verbs'])}
        max_elem = max(length_list.items(), key=operator.itemgetter(1))[0]
        print(max_elem)
        item_dicts[max_elem] = item_dicts[max_elem][:-1 or None]
        reduce_factor -= 1

    return ' '.join(item_dicts['named_entities']) + ' ' + ' '.join(item_dicts['nouns']) + ' ' + \
           ' '.join(item_dicts['verbs']) + ' ' + ' '.join(item_dicts['adj'])


def get_content(html):
    content = ''
    try:
        soup = BeautifulSoup(html, "html.parser")
        # kill all script and style elements
        for script in soup(["script", "style"]):
            script.extract()

        # get text
        text = soup.get_text()
        text = text[:5000]
        content = re.sub(r'[^\x00-\x7F]+', ' ', text)
        content = re.sub('\s+', ' ', content)
        content = content.encode('ascii', errors='ignore').decode("ascii")
    except Exception as e:
        print(str(e))
    return content


def get_html(url):
    html = ''
    try:
        if url.endswith('.pdf'):
            return html
        headers = {'User-Agent': 'Mozilla/5.0'}
        request= Request(url, headers=headers)
        site = urllib.request.urlopen(request, timeout=10)
        meta = site.info()
        size = [item[1] for item in meta._headers if item[0] == 'Content-Length']
        if not size or int(size[0]) < 5485760:
            html = site.read()
    except Exception as e:
        print(str(e))
    return html

def crawl_websites():
    ql = load_data.load_claims()
    data = []
    for item in ql:
        with open('data/web_augmentation/external/' + item[0] + '.json', 'r') as r:
            data.append(json.load(r))

    for on in data:
        print('Processing', on['id'])
        on['html'] = []
        for l in on['links']:
            sleep(0.5)
            html = get_html(l)
            text = get_content(html)
            on['html'].append(text)

        with open('data/web_augmentation/external/' + str(on['id']) + '.json', 'w') as outfile:
            json.dump(on, outfile, indent=2)



def prepare_query_and_search(search_function, elemments_selector, filepath):
    count = 0
    with open('data/claims_queries', 'r') as r:
        data = r.readlines()

    for item in data:
        parsed_json = json.loads(item)

        final_object = {'id': parsed_json['id']}
        _id = int(parsed_json['id'] )
        print('processing', str(_id))
        search_query = generate_search_query(parsed_json['nes'], parsed_json['nouns'], parsed_json['verbs'], parsed_json['adj'], reduce_factor=0)
        sleep(0.3)  # Google misbehaves if a lot of queries are sent rapidly
        final_object['initial_query'] = search_query
        final_object['relaxed_query'] = search_query
        results = search_function(search_query, item[1])

        result_count = len(results[elemments_selector[0]])
        tries = 0
        while result_count < 2:
            tries += 1
            search_query = generate_search_query(parsed_json['nes'], parsed_json['nouns'], parsed_json['verbs'],
                                                 parsed_json['adj'], reduce_factor=tries)

            sleep(0.3) #Google misbehaves if a lot of queries are sent rapidly

            final_object['relaxed_query'] = search_query
            if len(search_query.strip()) == 0:
                break
            results = search_function(search_query, item[1])
            results_copy = copy.deepcopy(results)

            for element in elemments_selector:
                if results_copy and element in results_copy:
                    results_copy = results_copy.get(element)
                else:
                    result_count = -1
                    break
            if result_count != -1:
                result_count = len(results_copy)
        final_object.update(results)
        with open(filepath + str(final_object['id']) + '.json', 'w') as outfile:
            json.dump(final_object, outfile, indent=2)
        count += 1


def process_google():
    googleCSE = GoogleSearch()
    prepare_query_and_search(googleCSE.search, ["links"], 'data/web_augmentation/external/')
    crawl_websites()



if __name__ == '__main__':
    process_google()
