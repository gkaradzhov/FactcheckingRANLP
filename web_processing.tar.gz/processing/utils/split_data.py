import numpy as np
from utils import load_data

def test_distribution(Y):
    pos = 0
    neg = 0
    for res in Y:
        if str(res) == '1':
            pos += 1
        else:
            neg += 1
    print('Positive', str(pos / (pos + neg)))
    print('Negative', str(neg / (pos + neg)))
    print(pos)
    print(neg)


train_size = 0.8 #from total
val_size = 0.5 #from remaining
test_size = 0.5 #from remaining

claims = load_data.load_claims()
claim_ids = [c[0] for c in claims]
ids_to_shuffle = np.asarray(claim_ids)

nb_train = int(train_size * ids_to_shuffle.shape[0])
remaining = ids_to_shuffle.shape[0] - nb_train
nb_val = int(val_size * remaining)
nb_test = remaining - nb_val
np.random.seed(seed=42)
np.random.shuffle(ids_to_shuffle)

train_questions = ids_to_shuffle[:nb_train]
val_questions = ids_to_shuffle[nb_train:(nb_train + nb_val)]
test_questions = ids_to_shuffle[(nb_train+nb_val):]


train_comments = []
test_comments = []
val_comments = []

train_labels = []
test_labels = []
val_labels = []


train_indexes = []
test_indexes = []
val_indexes = []


claim_ids = [c[0] for c in claims]
labels = [1 if 'true' in c[1] else 0 for c in claims]


for claim, label in zip(claim_ids, labels):
    if claim in train_questions:
        train_labels.append(label)
        train_indexes.append(str(claim))
    if claim in test_questions:
        test_labels.append(label)
        test_indexes.append(str(claim))
    if claim in val_questions:
        val_labels.append(label)
        val_indexes.append(str(claim))



print("Innitial")
test_distribution(labels)

print("Train")
test_distribution(train_labels)

print("Test")
test_distribution(test_labels)

print("Val")
test_distribution(val_labels)

#
with open("../data/test_ids", 'w', encoding='utf8') as w:
    w.write('\n'.join(test_indexes))

with open("../data/train_ids", 'w', encoding='utf8') as w:
    w.write('\n'.join(train_indexes))

with open("../data/val_ids", 'w', encoding='utf8') as w:
    w.write('\n'.join(val_indexes))


