import numpy as np

def get_train(ids, X, Y):
    with open("../data/train_ids", 'r', encoding='utf8') as w:
        train = w.readlines()
        train_indices = []
        for t in train:
            train_indices.append(t.replace('\n', ''))

    train_x = []
    train_y = []
    for id, x, y in zip(ids, X, Y):
        if id in train_indices:
            train_x.append(x)
            if Y is not None:
                train_y.append(y)
    return np.asarray(train_x), np.asarray(train_y)

def get_test(ids, X, Y):
    with open("../data/test_ids", 'r', encoding='utf8') as w:
        test = w.readlines()
        test_indices = []
        for t in test:
            test_indices.append(t.replace('\n', ''))

    test_x = []
    test_y = []
    for id, x, y in zip(ids, X, Y):
        if id in test_indices:
            test_x.append(x)
            if Y is not None:
                test_y.append(y)
    return np.asarray(test_x), np.asarray(test_y)

def get_val(ids, X, Y):
    with open("../data/val_ids", 'r', encoding='utf8') as w:
        val = w.readlines()
        val_indices = []
        for t in val:
            val_indices.append(t.replace('\n', ''))

    val_x = []
    val_y = []
    for id, x, y in zip(ids, X, Y):
        if id in val_indices:
            val_x.append(x)
            if Y is not None:
                val_y.append(y)
    return np.asarray(val_x), np.asarray(val_y)