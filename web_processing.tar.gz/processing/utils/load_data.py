import csv

def load_claims():
    result = []
    with open("data/claims-procesed", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result


def load_snippets():
    result = []
    with open("../data/feature_sets/best_snippets", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result

def load_websites():
    result = []
    with open("../data/feature_sets/best_websites", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result

def load_similarities():
    result = []
    with open("../data/feature_sets/similarities", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result

def load_linguistic():
    result = []
    with open("../data/feature_sets/linguistic_features", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result

def load_credibility():
    result = []
    with open("../data/feature_sets/credibility", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result

def load_avg_vectors():
    result = []
    with open("../data/feature_sets/avg_vector", 'r', encoding='UTF-8') as read_file:
        reader = csv.reader(read_file, delimiter="\t")
        for claim in reader:
            result.append(claim)
    return result