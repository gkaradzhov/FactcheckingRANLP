import numpy as np


def get_text_vector_array(text, embeddings, tokenizer):
    text_embeddings = []
    tokens = tokenizer(text)
    for token in tokens:
        token_lowered = token.lower()
        if token_lowered in embeddings:
            text_embeddings.append(list(embeddings[token_lowered]))
    return text_embeddings


def get_text_vector(text, embeddings, tokenizer):
    text_embeddings = get_text_vector_array(text, embeddings, tokenizer)
    if len(text_embeddings) == 0:
        empty = np.empty(300)
        empty.fill(0)
        return empty
    vector = np.sum(text_embeddings, axis=0) / len(text_embeddings)
    return vector


def get_mean(a):
    l = len(a)
    if l > 0:
        return np.mean(a).astype(float)
    else:
        return 0


def get_max(a):
    l = len(a)
    if l > 0:
        return np.max(a).astype(float)
    else:
        return 0


def get_min(a):
    l = len(a)
    if l > 0:
        return np.min(a).astype(float)
    else:
        return 0