import csv
import datetime


def evaluate_run_save_to_file(Ytest, predicted, runName):
    factual = 0
    truePositive = 0
    falseNegative = 0
    not_factual = 0
    trueNegative = 0
    falsePositive = 0
    for p, actual in zip(predicted, Ytest):
        print(p, actual)
        if actual == 1:
            factual += 1
            if actual == p:
                truePositive += 1
            else:
                falseNegative += 1
        else:
            not_factual += 1
            if actual == p:
                trueNegative += 1
            else:
                falsePositive += 1

    accuracy = (truePositive + trueNegative) / (falseNegative + truePositive + falsePositive + trueNegative)
    precission = (truePositive) / (truePositive + falsePositive)
    recall = (truePositive) / (truePositive + falseNegative)
    fScore = 2 * (precission * recall) / (precission + recall)
    with open('run-results.tsv', 'a', newline='') as csvFile:
        writer = csv.writer(csvFile, delimiter='\t')
        writer.writerow(
            [runName, str(datetime.datetime.now().date()), truePositive, trueNegative, falsePositive, falseNegative,
             accuracy, precission, recall, fScore])