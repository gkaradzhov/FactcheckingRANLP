import os
import numpy as np
import json
import csv
import urllib
from time import sleep
from utils.load_data import load_claims

def get_embeddings():
    embeddings_index = {}
    f = open('/mnt/hgfs/Shared/glove.6B.300d.txt') #path to embeddigns
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        embeddings_index[word] = coefs
    f.close()

    return embeddings_index


def get_website_credibility():

    categories ={'neg': [101, 102, 103, 104, 105, 201, 202, 203, 204, 205, 206, 207],
                'neu': [301, 302, 303, 304],
                'pos': [501]}

    site_cred = dict()
    with open('../data/web_augmentation/websites_list_credibility_data', 'r') as outfile:
        for item in outfile.readlines():
            obj = json.loads(item.strip())
            website = list(obj.keys())[0]
            site_cred[website] = obj[website]

    for site in site_cred:
        site_cred[site]['credibility'] = 0
        site_cred[site]['pos_count'] = 0
        site_cred[site]['neg_count'] = 0
        site_cred[site]['neu_count'] = 0
        if '0' in site_cred[site]:
            cred = site_cred[site]['0']
            confidence = (cred[1] + 30) / 100
            if cred[0] > 50:
                credibility = (cred[0] - 50) / 50
            else:
                credibility = (-50 + cred[0]) / 50

            site_cred[site]['credibility'] = credibility * confidence

        if 'categories' in site_cred[site]:
            for key, item in site_cred[site]['categories'].items():
                if item > 20:
                    if int(key) in categories['pos']:
                        site_cred[site]['pos_count'] += 1
                    if int(key) in categories['neg']:
                        site_cred[site]['neg_count'] += 1
                    if int(key) in categories['neu']:
                        site_cred[site]['neu_count'] += 1


    return site_cred




__url = "http://api.mywot.com/0.4/public_link_json2?hosts={}/&callback=process&key=d6fbdaeebde3de19517cac9901a12015a6cd796c"

def __get_unique_urls():
    urls = dict()
    data = load_claims()
    for d in data:
        print(d[0])
        with open('data/web_augmentation/external/' + d[0] + '.json', 'r') as r:
            claim_object = json.load(r)

        for link in claim_object['displayUrl']:
            if link in urls:
                urls[link] += 1
            else:
                urls[link] = 1

    import operator
    sorted_x = sorted(urls.items(), key=operator.itemgetter(1), reverse=True)
    with open('../data/web_augmentation/websites_list', 'w') as outfile:
        csvwriter = csv.writer(outfile, delimiter='\t')
        for item in sorted_x:
            csvwriter.writerow(item)

def __fetch_website_credibility_remote():
    sites = []
    with open('../data/web_augmentation/websites_list', 'r') as outfile:
        csvwriter = csv.reader(outfile, delimiter='\t')
        for site in csvwriter:
            sites.append(site)

    site_credibility = []
    try:
        for site in sites:
            sleep(1)
            req_url = url.format(site[0])
            print(req_url)
            site = urllib.request.urlopen(req_url, timeout=10)
            html = site.read().decode()
            html = html.replace("process(", '')
            html = html.replace(')', '')
            site_credibility.append(html)
    except:
        print('Exception')

    with open('../data/web_augmentation/websites_list_credibility_data', 'w') as outfile:
        for item in site_credibility:
            outfile.writelines(item + '\n')
