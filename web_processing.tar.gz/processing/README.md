# Factchecking
0. This project uses python3 with packages installed with pip3 package manager. Execute:
export PYTHONPATH=.
1. Install requirements: Run:
pip install -r requirements.txt
2. Install nltk additional data. Run:
python nltk_requirements.py
3. Execute the following file to run the pipeline:
python web_augmentation/run_web_augmenation_pipeline.py


--------------------------
Things to change in the code:
1. Path to word embeddings: in file utils/resources.py -> function get_embeddings
2. Path to data: utils/load_data -> function load_claims. The following format is assumed for the data:
<id>\t<class>\t<text>
Sample file is uploaded in data/claims-procesed
If you want to use different format please modify the code accordingly. 
3. Credentials for google search in web_augmentation/google_search. The credentials can be acquired on:
 3.1 cse_id: https://cse.google.com/cse/
 3.2 api key: https://console.developers.google.com
4. Path to IDFs: web_augmentation/extract_query_parts.py -> function extract_queries
Note: it will work without IDF dictionary provided, but default IDF of 1.5 will be assumed 
